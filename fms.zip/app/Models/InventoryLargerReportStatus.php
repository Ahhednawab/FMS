<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InventoryLargerReportStatus extends Model
{
    protected $table = 'inventory_larger_report_status';
    protected $fillable = ['name'];
}

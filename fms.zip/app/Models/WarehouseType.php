<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WarehouseType extends Model
{
    protected $table = 'warehouse_types';
    protected $fillable = ['name'];
}

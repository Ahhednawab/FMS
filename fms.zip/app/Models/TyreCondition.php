<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TyreCondition extends Model
{
    protected $table = 'tyre_conditions';
    protected $fillable = ['name'];
}

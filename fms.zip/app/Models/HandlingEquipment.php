<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HandlingEquipment extends Model
{
    protected $table = 'handling_equipments';
    protected $fillable = ['name'];
}

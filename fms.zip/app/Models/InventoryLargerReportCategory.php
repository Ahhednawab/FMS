<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InventoryLargerReportCategory extends Model
{
    protected $table = 'inventory_larger_report_category';
    protected $fillable = ['name'];
}

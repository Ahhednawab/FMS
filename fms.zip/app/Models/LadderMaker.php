<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LadderMaker extends Model
{
    protected $table = 'ladder_maker';
    protected $fillable = ['name'];
}

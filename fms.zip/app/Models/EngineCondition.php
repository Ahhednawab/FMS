<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EngineCondition extends Model
{
    protected $table = 'engine_conditions';
    protected $fillable = ['name'];
}

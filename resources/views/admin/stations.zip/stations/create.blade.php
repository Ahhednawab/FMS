@extends('layouts.admin')

@section('title', 'Create Station')

@section('content')
  <div class="page-header page-header-light">
    <div class="page-header-content header-elements-lg-inline">
      <div class="page-title d-flex">
        <h4><i class="icon-arrow-left52 mr-2"></i> <span class="font-weight-semibold">Create Station</span></h4>
        <a href="#" class="header-elements-toggle text-body d-lg-none"><i class="icon-more"></i></a>
      </div>
      <div class="header-elements d-none">
        <div class="d-flex justify-content-center">
          <a href="{{ route('admin.stations.index') }}" class="btn btn-primary">
            <span>View Station <i class="icon-list ml-2"></i></span>
          </a>
        </div>
      </div>
    </div>
  </div>

  <div class="content">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <form method="POST" action="{{ route('admin.stations.store') }}">
              @csrf

              <div class="row">
                <!-- Serial No -->
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Serial NO</label>
                    <input type="text" name="serial_no" class="form-control" value="{{$serial_no}}" readonly>
                  </div>
                </div>

                <!-- Country -->
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Country</label>
                    <select name="country_id" id="country_id" class="form-control">
                      <option value="">Select Country</option>
                      @foreach($countries as $country)
                        <option value="{{ $country->id }}" {{ old('country_id') == $country->id ? 'selected' : '' }}>
                          {{ $country->name }}
                        </option>
                      @endforeach
                    </select>
                    @if ($errors->has('country_id'))
                      <label class="text-danger">{{ $errors->first('country_id') }}</label>
                    @endif
                  </div>
                </div>

                <!-- City -->
                <div class="col-md-3">
                  <div class="form-group">
                    <label>City</label>
                    <select name="city_id" id="city_id" class="form-control">
                      <option value="">Select City</option>
                      @foreach($countries as $country)
                        @foreach($country->cities as $city)
                          <option value="{{ $city->id }}"
                            data-country="{{ $country->id }}"
                            {{ old('city_id') == $city->id ? 'selected' : '' }}>
                            {{ $city->name }}
                          </option>
                        @endforeach
                      @endforeach
                    </select>
                    @if ($errors->has('city_id'))
                      <label class="text-danger">{{ $errors->first('city_id') }}</label>
                    @endif
                  </div>
                </div>

                <!-- Area -->
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Area</label>
                    <input type="text" name="area" class="form-control" value="{{ old('area') }}">
                    @if ($errors->has('area'))
                      <label class="text-danger">{{ $errors->first('area') }}</label>
                    @endif
                  </div>
                </div>

                <!-- Buttons -->
                <div class="col-md-12">
                  <div class="text-right">
                    <button type="submit" class="btn btn-warning">Save</button>
                    <a href="{{ route('admin.stations.index') }}" class="btn btn-primary">Cancel</a>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
      const countrySelect = document.getElementById('country_id');
      const citySelect = document.getElementById('city_id');

      function filterCities() {
        const selectedCountry = countrySelect.value;
        [...citySelect.options].forEach(option => {
          if (!option.value) return; // keep default
          option.style.display = option.getAttribute('data-country') === selectedCountry ? 'block' : 'none';
        });
        citySelect.value = '';
      }

      countrySelect.addEventListener('change', filterCities);
      filterCities(); // run on load in case of edit
    });
  </script>
@endsection